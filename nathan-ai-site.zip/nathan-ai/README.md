# Nathan AI

Site demonstrativo com chat conectado à OpenAI Responses API por uma função server-side da Vercel.

## Publicar
1. Envie estes arquivos para um repositório GitHub.
2. Importe o repositório em https://vercel.com/new.
3. Em Project Settings → Environment Variables, adicione `OPENAI_API_KEY` com sua chave da OpenAI.
4. Faça um novo deploy após salvar a variável.

A chave fica no servidor e não deve ser colocada no HTML, no GitHub ou em mensagens públicas.

## Rodar localmente
Instale Node.js e execute:
```bash
npm install
npx vercel dev
```
Crie `.env.local` na raiz e adicione:
```env
OPENAI_API_KEY=sua_chave_aqui
```
Nunca compartilhe essa chave. A API pode gerar custos conforme o uso e a conta precisa ter faturamento/créditos configurados.
